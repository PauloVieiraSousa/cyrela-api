package com.cyrela;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CyrelaApplicationTests {

	@Test
	void contextLoads() {
	}

}
