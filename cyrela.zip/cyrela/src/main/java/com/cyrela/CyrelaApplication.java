package com.cyrela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyrelaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CyrelaApplication.class, args);
	}

}
